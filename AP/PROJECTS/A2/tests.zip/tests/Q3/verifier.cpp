#include <bits/stdc++.h>
using namespace std;

const int BOARD_SIZE = 7;
const int DIRECTION_COUNT = 4;

const int ROW_STEP[DIRECTION_COUNT] = {0, 0, 1, -1};
const int COL_STEP[DIRECTION_COUNT] = {1, -1, 0, 0};

map<string, int> directionMap = {
    {"RIGHT", 0}, {"LEFT", 1}, {"DOWN", 2}, {"UP", 3}};

bool isInsideBoard(int row, int col)
{
    return row >= 0 && row < BOARD_SIZE && col >= 0 && col < BOARD_SIZE;
}

int countPegs(const vector<string> &board)
{
    int pegCount = 0;
    for (const string &rowString : board)
        for (char cell : rowString)
            if (cell == 'N')
                pegCount++;
    return pegCount;
}

pair<int, int> convertNameToCell(const string &name)
{
    int row = name[0] - 'A';
    int col = name[1] - '1';
    return {row, col};
}

bool applyMove(vector<string> &board, string cellName, string directionName)
{
    if (!directionMap.count(directionName))
        return false;

    auto [row, col] = convertNameToCell(cellName);
    int direction = directionMap[directionName];

    int midRow = row + ROW_STEP[direction];
    int midCol = col + COL_STEP[direction];
    int targetRow = row + 2 * ROW_STEP[direction];
    int targetCol = col + 2 * COL_STEP[direction];

    if (!isInsideBoard(targetRow, targetCol))
        return false;
    if (board[row][col] != 'N')
        return false;
    if (board[midRow][midCol] != 'N')
        return false;
    if (board[targetRow][targetCol] != 'O')
        return false;

    board[row][col] = 'O';
    board[midRow][midCol] = 'O';
    board[targetRow][targetCol] = 'N';
    return true;
}

int main(int argc, char *argv[])
{
    if (argc < 2)
    {
        cerr << "Usage: verifier <test_number>\n";
        return 0;
    }

    string test_number = string(argv[1]);
    ifstream inputFile(test_number + "/" + test_number + ".in");
    ifstream outputFile(test_number + "/" + test_number + ".output");

    vector<string> board(BOARD_SIZE);
    for (int row = 0; row < BOARD_SIZE; row++)
        inputFile >> board[row];

    if (!outputFile)
    {
        cerr << "Missing output\n";
        return 0;
    }

    vector<string> tokens;
    string token;
    while (outputFile >> token)
        tokens.push_back(token);

    if (tokens.size() == 1 && tokens[0] == "Loser")
    {
        if (countPegs(board) == 1 && board[3][3] == 'N') {
            cout << "Wrong: Board already winning\n";
            return 1;
        }
        return 0;
    }

    if (tokens.size() % 2 != 0)
    {
        cout << "Invalid output format\n";
        return 1;
    }

    for (size_t i = 0; i < tokens.size(); i += 2)
    {
        string cellName = tokens[i];
        string directionName = tokens[i + 1];

        if (!applyMove(board, cellName, directionName))
        {
            cout << "Invalid move: " << cellName << " " << directionName << "\n";
            return 1;
        }
    }

    if (countPegs(board) == 1 && board[3][3] == 'N')
        return 0;
    cout << "Final state is not winning\n";
    return 1;
}