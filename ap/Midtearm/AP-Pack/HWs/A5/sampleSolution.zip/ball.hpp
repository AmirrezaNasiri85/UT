#ifndef BALL_HPP
#define BALL_HPP

#include <vector>
#include <cstdlib>
#include <cmath>
#include "wall.hpp"
#include "area.hpp"
#include "hole.hpp"

const float MAX_NORMAL_AREA_VELOCITY = 0.05;
const float MAX_SAND_AREA_VELOCITY = 0.015;
const int MAX_THROW_RADIUS = 100;
const float K_SCALE = 1.5;

using namespace std;

class Ball {
public:
    void set(float x, float y);
    bool is_there_any_wall(vector<Wall> wall);
    bool is_a_sharp_wall(vector<Wall> wall);

    int where_am_i(vector<Area> area);
    void set_velocity(vector<Area> area);
    float find_Vx();
    float find_Vy();
    void update(Window* window, vector<Area> area, vector<Wall> wall);
    void draw(Window* window);
    bool is_mouse_on_ball(Point mouse_position);
    Point find_destination(Point mouse_position);
    void set_destination(Point mouse_release_point);
    void browse_shot_counter();
    void set_status(bool is_hit);
    bool is_hit();
    Point get_current_position();
    bool is_in_hole(Hole hole);


private:
    float _x;
    float _y;
    int _radius;
    bool _is_hit;
    float _x_dst;
    float _y_dst;
    float _velocity;
    int _shot_counter;
    int _area_ID;
};
#endif
