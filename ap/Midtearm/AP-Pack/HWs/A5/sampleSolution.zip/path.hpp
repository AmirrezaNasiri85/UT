#ifndef PATH_HPP
#define PATH_HPP

#include "ball.hpp"

class Path {
public:
    void draw(Window* window, Ball ball);
};

#endif
