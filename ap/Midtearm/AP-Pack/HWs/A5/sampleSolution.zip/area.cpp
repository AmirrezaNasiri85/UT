#include "area.hpp"
Area::Area(int x, int y, int width, int height, int area_type) {
    _x = x; _y = y; _w = width, _h = height;
    _area_type = area_type;
}

void Area::draw(Window* window) {
    if (_area_type == WATER_AREA_ID)
        window->fill_rect(Rectangle(_x, _y, _w, _h), WATER_COLOR);
    else if (_area_type == NORMAL_AREA_ID)
        window->fill_rect(Rectangle(_x, _y, _w, _h), DARK_GREEN);
    else if (_area_type == SAND_AREA_ID)
        window->fill_rect(Rectangle(_x, _y, _w, _h), SAND_COLOR);
}

bool Area::contain_ball(int x, int y) {
    return (x >= _x && x <= (_x + _w) && y >= _y && y <= (_y + _h));
}

int Area::get_ID() { return _area_type; }