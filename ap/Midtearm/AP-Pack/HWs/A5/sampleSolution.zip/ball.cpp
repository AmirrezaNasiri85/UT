#include "ball.hpp"
using namespace std;

void Ball::set(float x, float y) {
    _x = x;
    _y = y;
    _radius = BALL_RADIUS;
    _is_hit = false;
    _x_dst = _x;
    _y_dst = _y;
    _area_ID = NORMAL_AREA_ID;
    _velocity = MAX_NORMAL_AREA_VELOCITY;
    _shot_counter = 0;
}

bool Ball::is_there_any_wall(vector<Wall> wall) {
    for (int i = 0; i < wall.size(); i++) {
        if (wall[i].touch_ball(_x, _y))
            return true;
    }
    return false;
}

bool Ball::is_a_sharp_wall(vector<Wall> wall) {
    for (int i = 0; i < wall.size(); i++) {
        if ((wall[i].touch_ball(_x, _y)) && wall[i].is_sharp_wall())
            return true;
    }
    return false;
}

int Ball::where_am_i(vector<Area> area) {
    for (int i = 0; i < area.size(); i++) {
        if (area[i].contain_ball(_x, _y))
            return area[i].get_ID();
    }
    return NORMAL_AREA_ID;
}

void Ball::set_velocity(vector<Area> area) {
    int _area_ID = where_am_i(area);
    if (_area_ID == NORMAL_AREA_ID)
        _velocity = MAX_NORMAL_AREA_VELOCITY;
    else if (_area_ID == SAND_AREA_ID)
        _velocity = MAX_SAND_AREA_VELOCITY;
}

float Ball::find_Vx() {
    float disdance = sqrt(pow((_x_dst - _x), 2) + pow((_y_dst - _y), 2));
    if (disdance > MAX_THROW_RADIUS)
        disdance = MAX_THROW_RADIUS;
    float Vx = _velocity * ((_x_dst - _x) / sqrt(pow((_x_dst - _x), 2) + pow((_y_dst - _y), 2))) * disdance;
    return Vx;
}

float Ball::find_Vy() {
    float disdance = sqrt(pow((_x_dst - _x), 2) + pow((_y_dst - _y), 2));
    if (disdance > MAX_THROW_RADIUS)
        disdance = MAX_THROW_RADIUS;
    float Vy = _velocity * ((_y_dst - _y) / sqrt(pow((_x_dst - _x), 2) + pow((_y_dst - _y), 2))) * disdance;
    return Vy;
}

void Ball::update(Window* window, vector<Area> area, vector<Wall> wall) {
    if (is_there_any_wall(wall)) {
        if (!is_a_sharp_wall(wall)) {
            int wall_id;
            for (int i = 0; i < wall.size(); i++) {
                if (wall[i].touch_ball(_x, _y)) {
                    wall_id = i;
                }
            }
            wall[wall_id].reflect(_x_dst, _y_dst, _x, _y);

        }
    }
    set_velocity(area);
    float Vx = find_Vx();
    float Vy = find_Vy();
    if (abs(_x - _x_dst) > 1) {
        _x = _x + Vx;
    }
    if (abs(_y - _y_dst) > 1) {
        _y = _y + Vy;
    }
}

void Ball::draw(Window* window) {
    window->fill_circle(Point(_x, _y), _radius);
    string string_shot_counter = to_string(_shot_counter);
    window->show_text(string_shot_counter, Point(window->get_width() / 2, window->get_height() - 50), MAGENTA, "./FreeSans.ttf", 24);
}

bool Ball::is_mouse_on_ball(Point mouse_position) {
    if (pow((mouse_position.x - _x), 2) + pow((mouse_position.y - _y), 2) - pow(_radius, 2) <= 0) {
        return true;
    }
    return false;
}

Point Ball::find_destination(Point mouse_position) {
    float x_dst = (K_SCALE)*_x - (K_SCALE - 1) * mouse_position.x;
    float y_dst = (K_SCALE)*_y - (K_SCALE - 1) * mouse_position.y;
    return Point(x_dst, y_dst);
}

void Ball::set_destination(Point mouse_release_point) {
    _x_dst = (K_SCALE + 0.5) * _x - (K_SCALE - 0.5) * mouse_release_point.x;
    _y_dst = (K_SCALE + 0.5) * _y - (K_SCALE - 0.5) * mouse_release_point.y;

}

void Ball::browse_shot_counter() {
    _shot_counter++;
}

void Ball::set_status(bool is_hit) {
    _is_hit = is_hit;
}

bool Ball::is_hit() {
    return _is_hit;
}

Point Ball::get_current_position() {
    return Point(_x, _y);
}

bool Ball::is_in_hole(Hole hole) {
    return (hole.contain_ball(_x, _y, _radius));
}