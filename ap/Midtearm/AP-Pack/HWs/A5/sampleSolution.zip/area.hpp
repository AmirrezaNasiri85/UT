#ifndef AREA_HPP
#define AREA_HPP

#include "rsdl.hpp"

const RGB DARK_GREEN(0, 100, 0);
const int NORMAL_AREA_ID = 0;
const int WATER_AREA_ID = 2;
const int SAND_AREA_ID = 1;
const RGB WATER_COLOR(0, 100, 255);
const RGB SAND_COLOR(150, 150, 100);

class Area {
public:
    Area(int x, int y, int width, int height, int area_type);
    void draw(Window* window);
    bool contain_ball(int x, int y);
    int get_ID();

private:
    int _x;
    int _y;
    int _w;
    int _h;
    int _area_type;

};
#endif