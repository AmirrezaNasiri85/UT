#ifndef HOLE_HPP
#define HOLE_HPP

#include "rsdl.hpp"
const int HOLE_RADIUS = 20;


class Hole {
public:
    void set(float x, float y);
    void draw(Window* window);
    bool contain_ball(float x, float y, int radius);
private:
    float _x;
    float _y;
    int _radius;
};

#endif