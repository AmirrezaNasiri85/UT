#ifndef WALL_HPP
#define WALL_HPP

#include "rsdl.hpp"
const int BALL_RADIUS = 10;
const RGB NORMAL_WALL_COLOR(200,200, 0);
const RGB SHARP_WALL_COLOR(250, 50, 50);
const int MOVMENT = 50;

class Wall {
public:
    Wall(int x, int y, int width, int height, bool is_sharp_wall, bool can_move);
    void draw(Window* window);
    bool is_sharp_wall();
    bool touch_ball(float x, float y);
    void reflect(float& x_dst, float& y_dst, float x_src, float y_src);

    void update(Window* window);

private:
    int _x;
    int _y;
    int _w;
    int _h;
    bool _sharp_wall;
    bool _can_move;
    int _const_x;
    int _const_y;
    bool _positive_move;
};

#endif
