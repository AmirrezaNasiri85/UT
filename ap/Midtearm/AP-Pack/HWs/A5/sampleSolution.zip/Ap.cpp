#include <iostream>
#include <fstream>
#include "path.hpp"

#include <string>
using namespace std;

const int DELAY = 10;

void update(Window* window, Ball& ball, Hole& hole, vector<Wall>& wall, vector<Area>& area, Path path) {
    while (window->has_pending_event()) {
        Event event = window->poll_for_event();
        switch (event.get_type()) {
        case Event::EventType::QUIT:
            exit(0);
            break;
        case Event::EventType::LCLICK: {
            if (ball.is_mouse_on_ball(get_current_mouse_position())) {
                ball.set_status(true);
                break;
            }
        case Event::EventType::LRELEASE: {
            if (ball.is_hit()) {
                ball.set_destination(get_current_mouse_position());
                ball.browse_shot_counter();
            }
            ball.set_status(false);
            break;
        }
        }
        }
    }

    ball.update(window, area, wall);
    for (int i = 0; i < wall.size(); i++) {
        wall[i].update(window);
    }
}

void draw(Window* window, Ball ball, Hole hole, vector<Wall> wall, vector<Area> area, Path path, bool& is_end) {
    if (!is_end) {
        window->clear();
        for (int i = 0; i < area.size(); i++)
            area[i].draw(window);
        for (int i = 0; i < wall.size(); i++)
            wall[i].draw(window);

        hole.draw(window);
        ball.draw(window);
        path.draw(window, ball);
        if (ball.where_am_i(area) == WATER_AREA_ID) {
            window->clear();
            window->show_text("oh, nooo!", Point(window->get_width() / 2 - 50, window->get_height() / 2 - 25), RED, "./FreeSans.ttf", 18);
            window->show_text("you dropped the ball in water :(", Point(window->get_width() / 2 - 120, window->get_height() / 2 + 25), RED, "./FreeSans.ttf", 18);
            is_end = true;
        }
        if (ball.is_there_any_wall(wall))
            if (ball.is_a_sharp_wall(wall)) {
                window->clear();
                window->show_text("oh, nooo!", Point(window->get_width() / 2 - 50, window->get_height() / 2 - 25), RED, "./FreeSans.ttf", 18);
                window->show_text("ball touch a sharp wall :(", Point(window->get_width() / 2 - 120, window->get_height() / 2 + 25), RED, "./FreeSans.ttf", 18);
                is_end = true;
            }
        if (ball.is_in_hole(hole)) {
            window->clear();
            window->show_text("After a lot of hard work!!", Point(window->get_width() / 2 - 120, window->get_height() / 2 - 100), CYAN, "./FreeSans.ttf", 18);
            window->show_text("Hitting obsracles!!", Point(window->get_width() / 2 - 120, window->get_height() / 2 - 75), CYAN, "./FreeSans.ttf", 18);
            window->show_text("Falling into the salty water of Persian Golf!!!", Point(window->get_width() / 2 - 120, window->get_height() / 2 - 50), CYAN, "./FreeSans.ttf", 18);
            window->show_text("U WON ~(^_^)~!", Point(window->get_width() / 2 - 120, window->get_height() / 2 ), CYAN, "./FreeSans.ttf", 36);
            is_end = true;
        }
        window->update_screen();
    }
}

void read_map(char* argv[], int& _w, int& _h, Ball& ball, Hole& hole, vector<Wall>& wall, vector<Area>& area) {
    string  entity;
    string line;
    string file_name = argv[1];
    fstream fin(file_name, ios::in);
    float x, y, w, h;
    while (fin >> entity >> x >> y) {
        if (entity == "window_size") {
            _w = int(x);
            _h = int(y);
        }
        else if (entity == "ball") {
            ball.set(x, y);
        }
        else if (entity == "hole") {
            hole.set(x, y);
        }
        else if (entity == "water_area") {
            fin >> w >> h;
            area.push_back(Area(x, y, w, h, WATER_AREA_ID));
        }
        else if (entity == "normal_area") {
            fin >> w >> h;
            area.push_back(Area(x, y, w, h, NORMAL_AREA_ID));
        }
        else if (entity == "sand_area") {
            fin >> w >> h;
            area.push_back(Area(x, y, w, h, SAND_AREA_ID));
        }
        else if (entity == "wall") {
            fin >> w >> h;
            wall.push_back(Wall(x, y, w, h, false, false));
        }
        else if (entity == "sharp_wall") {
            fin >> w >> h;
            wall.push_back(Wall(x, y, w, h, true, false));
        }
        else if (entity == "moving_sharp_wall") {
            fin >> w >> h;
            wall.push_back(Wall(x, y, w, h, true, true));
        }
        else if (entity == "moving_wall") {
            fin >> w >> h;
            wall.push_back(Wall(x, y, w, h, false, true));
        }
    }
}

int main(int argc, char* argv[]) {
    int window_width, window_height;
    Ball ball;
    vector<Wall> wall;
    vector<Area> area;
    Hole hole;
    Path path;

    bool is_end = false;

    read_map(argv, window_width, window_height, ball, hole, wall, area);
    Window* window = new Window(window_width, window_height, "MINI GOLF");

    while (true) {
        update(window, ball, hole, wall, area, path);
        draw(window, ball, hole, wall, area, path, is_end);
        delay(DELAY);
    }
    return 0;
}