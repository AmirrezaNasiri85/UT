#include "wall.hpp"

using namespace std;


Wall::Wall(int x, int y, int width, int height, bool is_sharp_wall, bool can_move) {
    _x = x;
    _y = y;
    _w = width;
    _h = height;
    _const_x = x;
    _const_y = y;
    _sharp_wall = is_sharp_wall;
    _can_move = can_move;
  
    _positive_move = true;

}


void Wall::draw(Window* window) {
    if (_sharp_wall)
        window->fill_rect(Rectangle(_x, _y, _w, _h), SHARP_WALL_COLOR);
    else
        window->fill_rect(Rectangle(_x, _y, _w, _h), NORMAL_WALL_COLOR);
}
bool Wall::is_sharp_wall() { return _sharp_wall; }
bool Wall::touch_ball(float x, float y) {
    return (x >= (_x - BALL_RADIUS) && x <= (_x + _w + BALL_RADIUS) &&
        y >= (_y - BALL_RADIUS) && y <= (_y + _h + BALL_RADIUS));

}
void Wall::reflect(float& x_dst, float& y_dst, float x_src, float y_src) {
    if (x_src <= _x) {
        if (x_dst >= _x) {
            x_dst = _x * 2 - x_dst;
        }
        if (x_dst >= _x + _w) {
            x_dst = (_x + _w) * 2 - x_dst;
        }

    }
    if (x_src >= (_x + _w)) {
        x_dst = (_x + _w) * 2 - x_dst;
    }

    if (y_src <= _y && y_dst >= _y) {
        y_dst = _y * 2 - y_dst;
    }
    if (y_src >= (_y + _h) && y_dst <= (_y + _h)) {
        y_dst = (_y + _h) * 2 - y_dst;
    }
}

void Wall::update(Window* window) {
    if (_can_move) {
        if (_w > _h) {
            if (_x < _const_x + MOVMENT){
                _x++;
            }
            if (_x == _const_x + MOVMENT) {
                if(!_positive_move) { 
                    _const_x =_const_x - 2 * MOVMENT;
                }
                else {
                    _const_x = _const_x + 2 * MOVMENT;
                }
                _positive_move = !_positive_move;
            }
            if (_x >  _const_x + MOVMENT){
                _x--;
            }
        }
        else {
            if (_y < _const_y + MOVMENT) {
                _y++;
            }
            if (_y == _const_y + MOVMENT) {
                if(!_positive_move) { 
                    _const_y =_const_y - 2 * MOVMENT;
                }
                else {
                    _const_y = _const_y + 2 * MOVMENT;
                }
                _positive_move = !_positive_move;
            }
            if (_y >  _const_y + MOVMENT){
                _y--;               
            }
        }   
    }
}