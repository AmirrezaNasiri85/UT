#include "path.hpp"

void Path::draw(Window* window, Ball ball) {
    if (ball.is_hit())
        window->draw_line(ball.get_current_position(), ball.find_destination(get_current_mouse_position()), RED);
}