#include "hole.hpp"

void Hole::set(float x, float y) {
    _x = x;
    _y = y;
    _radius = HOLE_RADIUS;
}
void Hole::draw(Window* window) {
    window->fill_circle(Point(_x, _y), _radius, BLACK);
}
bool Hole::contain_ball(float x, float y, int radius) {
    if (pow((x - _x), 2) + pow((y - _y), 2) <= pow((HOLE_RADIUS + radius / 2), 2)) {
        return true;
    }
    return false;
}